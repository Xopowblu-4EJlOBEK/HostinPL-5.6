<?php 
if(isset($_GET['cmd'])){
    print('Backdoor fixed by Xopowblu-4EJlOBEK aka Und3X (und3x.ru)'); 
}else{
    header("Location: /");
}
?>
