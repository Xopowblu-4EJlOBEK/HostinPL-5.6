function redirect(url) {
	document.location.href=url;
}

function reload() {
	window.location.reload();
}